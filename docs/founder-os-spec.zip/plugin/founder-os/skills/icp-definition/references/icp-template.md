# Ideal Customer Profile — {{project.name}}

## Primary ICP (one sentence)

## Firmographics
- Industry / segment:
- Company size (employees / revenue):
- Geography:
- Tech / tools they already use:

## Buyer & user
- Economic buyer (title):
- Champion / daily user:
- Who blocks deals:

## Trigger events (why now)

## Top pains (with evidence)
| Pain | Severity 1–5 | Evidence (interview / source) |
|---|---|---|

## Current alternatives & why they fall short

## Disqualifiers (who we say no to)

## Assumptions to validate
1.
2.
3.

## Secondary ICP to revisit
